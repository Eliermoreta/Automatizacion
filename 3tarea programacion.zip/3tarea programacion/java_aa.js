document.addEventListener('DOMContentLoaded', () => {
    const accidenteForm = document.getElementById('accidenteForm');
    const accidenteList = document.getElementById('accidenteList');
    const totalAccidentes = document.getElementById('totalAccidentes');
    const totalVehiculos = document.getElementById('totalVehiculos');
    const totalMuertos = document.getElementById('totalMuertos');
    const totalHeridos = document.getElementById('totalHeridos');

    // Cargar accidentes al inicio
    cargarAccidentes();

    accidenteForm.addEventListener('submit', (event) => {
        event.preventDefault();
        
        const nuevoAccidente = {
            fecha: document.getElementById('fecha').value,
            descripcion: document.getElementById('descripcion').value,
            costo: parseFloat(document.getElementById('costo').value),
            muertos: parseInt(document.getElementById('muertos').value),
            heridos: parseInt(document.getElementById('heridos').value),
            vehiculos: parseInt(document.getElementById('vehiculos').value),
        };

        agregarAccidente(nuevoAccidente);
        accidenteForm.reset();
        alert("Accidente agregado exitosamente!"); // Feedback al usuario
    });

    function agregarAccidente(accidente) {
        const accidentes = obtenerAccidentes();
        accidentes.push(accidente);
        guardarAccidentes(accidentes);
        mostrarAccidentes();  // Actualizar la lista de accidentes
        actualizarDashboard(); // Actualizar el dashboard
    }

    function obtenerAccidentes() {
        return JSON.parse(localStorage.getItem('accidentes')) || [];
    }

    function guardarAccidentes(accidentes) {
        localStorage.setItem('accidentes', JSON.stringify(accidentes));
    }

    function mostrarAccidentes() {
        const accidentes = obtenerAccidentes();
        accidenteList.innerHTML = ''; // Limpiar la lista actual

        accidentes.forEach((accidente) => {
            const li = document.createElement('li');
            li.textContent = `${accidente.fecha}: ${accidente.descripcion} (Costo: $${accidente.costo}, Muertos: ${accidente.muertos}, Heridos: ${accidente.heridos}, Vehículos: ${accidente.vehiculos})`;
            accidenteList.appendChild(li);
        });
    }

    function actualizarDashboard() {
        const accidentes = obtenerAccidentes();
        totalAccidentes.textContent = accidentes.length;
        totalVehiculos.textContent = accidentes.reduce((sum, acc) => sum + acc.vehiculos, 0);
        totalMuertos.textContent = accidentes.reduce((sum, acc) => sum + acc.muertos, 0);
        totalHeridos.textContent = accidentes.reduce((sum, acc) => sum + acc.heridos, 0);
    }

    function cargarAccidentes() {
        mostrarAccidentes();
        actualizarDashboard();
    }
});
