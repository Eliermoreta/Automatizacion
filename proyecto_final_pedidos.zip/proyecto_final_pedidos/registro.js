// Capturamos el formulario de registro
document.getElementById('registerForm').addEventListener('submit', function (event) {
    event.preventDefault();

    // Obtener valores de los campos
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirmPassword').value;

    // Validaciones básicas
    if (!name || !email || !password || !confirmPassword) {
        alert('Por favor, completa todos los campos.');
        return;
    }

    if (!email.includes('@') || !email.includes('.')) {
        alert('Por favor, ingresa un correo electrónico válido.');
        return;
    }

    if (password.length < 6) {
        alert('La contraseña debe tener al menos 6 caracteres.');
        return;
    }

    if (password !== confirmPassword) {
        alert('Las contraseñas no coinciden.');
        return;
    }

    // Simulación de registro exitoso
    alert('Registro exitoso. Por favor, inicia sesión para continuar.');
    // Redirigir a la página de login
    window.location.href = 'login.html';
});
